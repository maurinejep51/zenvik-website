                    </div>

                    </div>
                    {if !$inShoppingCart && $secondarySidebar->hasChildren()}
                        <div class="d-lg-none sidebar sidebar-secondary">
                            {include file="$template/includes/sidebar.tpl" sidebar=$secondarySidebar}
                        </div>
                    {/if}
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <footer id="footer" class="footer zt-footer">
        <div class="container">
            <div class="zt-footer-grid">
                <div class="zt-footer-column zt-footer-company">
                    <a class="zt-footer-brand" href="{$WEB_ROOT}/index.php">
                        <img src="{$WEB_ROOT}/templates/{$template}/img/logo.png" alt="{$companyname}" class="zt-footer-logo" onerror="{if $assetLogoPath}this.onerror=null;this.src='{$assetLogoPath}';{else}this.style.display='none';{/if}">
                    </a>
                    <p>Zenvik Technologies delivers premium hosting, domains, software, websites, and ICT support for businesses that need dependable digital infrastructure.</p>
                    <a class="zt-whatsapp-btn" href="https://wa.me/254717990272" target="_blank" rel="noopener">
                        <i class="fab fa-whatsapp"></i>
                        WhatsApp Support
                    </a>
                </div>

                <div class="zt-footer-column">
                    <h3>Hosting</h3>
                    <ul class="zt-footer-links">
                        <li><a href="{$WEB_ROOT}/cart.php">Web Hosting</a></li>
                        <li><a href="{$WEB_ROOT}/cart.php">VPS Hosting</a></li>
                        <li><a href="{$WEB_ROOT}/cart.php">WordPress Hosting</a></li>
                        <li><a href="{$WEB_ROOT}/cart.php">Email Hosting</a></li>
                        <li><a href="{$WEB_ROOT}/store/ssl">SSL Certificates</a></li>
                    </ul>
                </div>

                <div class="zt-footer-column">
                    <h3>Company</h3>
                    <ul class="zt-footer-links">
                        <li><a href="{$WEB_ROOT}/contact.php">{lang key='contactus'}</a></li>
                        <li><a href="{routePath('knowledgebase-index')}">Knowledgebase</a></li>
                        <li><a href="{$WEB_ROOT}/submitticket.php">Open Ticket</a></li>
                        <li><a href="{$WEB_ROOT}/serverstatus.php">Network Status</a></li>
                        <li><a href="{$WEB_ROOT}/affiliates.php">Affiliates</a></li>
                        {if $acceptTOS}
                            <li><a href="{$tosURL}" target="_blank">{lang key='ordertos'}</a></li>
                        {/if}
                    </ul>
                </div>

                <div class="zt-footer-column">
                    <h3>Contact</h3>
                    <ul class="zt-footer-contact">
                        <li><span>Phone</span><a href="tel:+254717990272">+254 717 990 272</a></li>
                        <li><span>Email</span><a href="mailto:info@zenviktechnologies.com">info@zenviktechnologies.com</a></li>
                        <li><span>Support</span><a href="mailto:support@zenviktechnologies.com">support@zenviktechnologies.com</a></li>
                        <li><span>Hosting</span><a href="mailto:hosting@zenviktechnologies.com">hosting@zenviktechnologies.com</a></li>
                    </ul>
                </div>
            </div>

            <div class="zt-footer-bottom">
                <p class="copyright mb-0">
                    {lang key="copyrightFooterNotice" year=$date_year company=$companyname}
                </p>
                <ul class="zt-footer-social">
                    {include file="$template/includes/social-accounts.tpl"}
                </ul>
            </div>
        </div>
    </footer>

    <div class="modal system-modal fade" id="modalAjax" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">{lang key='close'}</span>
                    </button>
                </div>
                <div class="modal-body">
                    {lang key='loading'}
                </div>
                <div class="modal-footer">
                    <div class="float-left loader">
                        <i class="fas fa-circle-notch fa-spin"></i>
                        {lang key='loading'}
                    </div>
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        {lang key='close'}
                    </button>
                    <button type="button" class="btn btn-primary modal-submit">
                        {lang key='submit'}
                    </button>
                </div>
            </div>
        </div>
    </div>

    <form method="get" action="{$currentpagelinkback}">
        <div class="modal modal-localisation" id="modalChooseLanguage" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                        {if $languagechangeenabled && count($locales) > 1}
                            <h5 class="h5 pt-5 pb-3">{lang key='chooselanguage'}</h5>
                            <div class="row item-selector">
                                <input type="hidden" name="language" data-current="{$language}" value="{$language}" />
                                {foreach $locales as $locale}
                                    <div class="col-4">
                                        <a href="#" class="item{if $language == $locale.language} active{/if}" data-value="{$locale.language}">
                                            {$locale.localisedName}
                                        </a>
                                    </div>
                                {/foreach}
                            </div>
                        {/if}
                        {if !$loggedin && $currencies}
                            <p class="h5 pt-5 pb-3">{lang key='choosecurrency'}</p>
                            <div class="row item-selector">
                                <input type="hidden" name="currency" data-current="{$activeCurrency.id}" value="">
                                {foreach $currencies as $selectCurrency}
                                    <div class="col-4">
                                        <a href="#" class="item{if $activeCurrency.id == $selectCurrency.id} active{/if}" data-value="{$selectCurrency.id}">
                                            {$selectCurrency.prefix} {$selectCurrency.code}
                                        </a>
                                    </div>
                                {/foreach}
                            </div>
                        {/if}
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-default">{lang key='apply'}</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    {if !$loggedin && $adminLoggedIn}
        <a href="{$WEB_ROOT}/logout.php?returntoadmin=1" class="btn btn-return-to-admin" data-toggle="tooltip" data-placement="bottom" title="{if $adminMasqueradingAsClient}{lang key='adminmasqueradingasclient'} {lang key='logoutandreturntoadminarea'}{else}{lang key='adminloggedin'} {lang key='returntoadminarea'}{/if}">
            <i class="fas fa-redo-alt"></i>
            <span class="d-none d-md-inline-block">{lang key="admin.returnToAdmin"}</span>
        </a>
    {/if}

    {include file="$template/includes/generate-password.tpl"}

    {$footeroutput}

</body>
</html>
